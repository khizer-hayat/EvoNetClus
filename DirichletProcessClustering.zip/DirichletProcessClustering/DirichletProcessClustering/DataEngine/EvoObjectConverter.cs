﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.Network;

namespace DirichletProcessClustering.DataEngine
{
    // Abstract class for T conversion
    public abstract class EvoObjectConverter<T>
    {
        protected List<EvoObject> _eConverted;

        public void Convert(List<T> _rawObjects)
        {
            List<EvoObject> _results = new List<EvoObject>(_rawObjects.Count);
            for (int _i = 0; _i < _rawObjects.Count; _i++)
            {
                _results.Add(ConvertPCV(_rawObjects[_i]));
            }
            _eConverted = new List<EvoObject>(_results);
            // _eConverted = _results.ToList();
            // return _results;
        }

        public abstract EvoObject ConvertPCV(T _o);

        public List<EvoObject> GetCurrentConversion()
        {
            return _eConverted;
        }
    }
}
