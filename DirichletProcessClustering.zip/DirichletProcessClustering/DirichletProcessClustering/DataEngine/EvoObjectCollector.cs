﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DirichletProcessClustering.DataEngine
{
    // Abstract class for T collection
    public abstract class EvoObjectCollector<T> 
    { 
        public List<T> _collection;

        public abstract void Collect(int _startYear, int _endYear); 

        public List<T> GetCurrentCollection() 
        { 
            return _collection;
        } 
    }  
 }
