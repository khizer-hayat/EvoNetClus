﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace DirichletProcessClustering.DataEngine
{
    // Database connection class
    public sealed class ConnectionClass : IDisposable
    {
        public SqlConnection cnn;

        public ConnectionClass()
        {
            if ((cnn = GetConnection()) == null)
            {
                this.Dispose();
            }
        }

        public SqlConnection GetConnection()
        {
            SqlConnection conn = null;

            string connStr = "Data Source=/*SQLServerName*/;Initial Catalog=/*DatabaseName*/;Integrated Security=True;MultipleActiveResultSets=True;";
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = connStr;
                conn.Open();

                return conn;
            }
            catch
            {
                conn.Dispose();
                return null;
            }
        }
        public void Dispose()
        {
            if (cnn != null)
            {
                cnn.Dispose();
            }
        }
    }
}

