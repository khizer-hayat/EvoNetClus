﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Diagnostics;
using DirichletProcessClustering.GraphData;

namespace DirichletProcessClustering.DataEngine
{
    // Class that collects authors (i.e. Target Objects i.e. EvoObjects)
    // and it extends an abstract class i.e. EvoObjectCollector<T>
    public class AuthorCollector : EvoObjectCollector<Author>   
    {
        static ConnectionClass _cs = new ConnectionClass();
        SqlConnection _con;

        // Class constructor
        public AuthorCollector()
        {
            _con = _cs.GetConnection();
            //_authors = CollectAuthors(_startYear, _endYear);
            //Collect(_startYear, _endYear);
        }

        // Class constructor overridden
        public AuthorCollector(int _startYear, int _endYear)
        {
            _con = _cs.GetConnection();
            //_authors = CollectAuthors(_startYear, _endYear);
            Collect(_startYear, _endYear);
        }

        // Overriding method of abstract class
        public override void Collect(int _startYear, int _endYear)
        {
            List<Author> _eAthors = new List<Author>();
            Author _fullListAuthors = new Author();
            //List<Author> _tAuthors = new List<Author>();

            try
            {
                SqlCommand _myCommand_1 = _con.CreateCommand();

                // sample query for author collection (only 20, here TOP (20) means first 20 authors sequentially appearing at top whereas Author_ID(s) may repeat in database
                _myCommand_1.CommandText = @"SELECT  AC.Author_ID, A.Author_Name, AC.Paper_ID, P.Paper_Category, AC.CoAuthor_ID, AP.Venue_ID, AC.Year
                                             FROM
                                             (
                                                SELECT TOP (20) AC.Author_ID
                                                FROM       AuthorCoAuthor AC
                                                GROUP BY   AC.Author_ID
                                                ORDER BY   AC.Author_ID
                                             ) DS
                                             JOIN    AuthorCoAuthor  AC ON AC.Author_ID = DS.Author_ID
                                             JOIN    AuthorPaper     AP ON AP.Author_ID = AC.Author_ID AND 
                                                                           AP.Paper_ID  = AC.Paper_ID
                                             JOIN    Author          A  ON A.Author_ID  = AC.Author_ID
                                             JOIN    Paper	     P  ON P.Paper_ID   = AP.Paper_ID
                                             ORDER BY AC.Author_ID, AC.Year, AC.Paper_ID, AC.CoAuthor_ID, AP.Venue_ID";
                int _Row_Counter = 0;   // Row Counter not desired as much

                using (SqlDataReader _myReader_1 = _myCommand_1.ExecuteReader())
                {
                    //.....this is the commented code if we use the class i.e. "AuthorAttributes.cs"
                    
                    //while (_myReader_1.Read())
                    //{
                    //    _Row_Counter++;

                    //    int _authorID = _myReader_1.GetInt32(0);
                    //    string _authorName = _myReader_1.GetString(1);
                    //    int _paperID = _myReader_1.GetInt32(2);
                    //    int _coAuthorID = _myReader_1.GetInt32(3);
                    //    int _venueID = _myReader_1.GetInt32(4);
                    //    //int _paperCategory = _myReader_1.GetInt32();
                    //    int _year = _myReader_1.GetInt32(5);

                    //    Author _author = _eAthors.FirstOrDefault(_a => _a._AuthorID == _authorID);
                    //    if (_author == null)
                    //    {
                    //        _author = new Author()
                    //        {
                    //            _AuthorID = _authorID,
                    //            _AuthorName = _authorName,
                    //            _Attributes = new AuthorAttributes()
                    //            {
                    //                _PaperID = new List<int>(),
                    //                _CoAuthorID = new List<int>(),
                    //                _VenueID = new List<int>(),
                    //                _Year = _year
                    //            }
                    //        };  
                        
                    //        _eAthors.Add(_author); // only add if author not found
                    //    }  

                    //    if ( !_author._Attributes._PaperID.Contains( _paperID ))
                    //        _author._Attributes._PaperID.Add( _paperID );
	
                    //    if ( !_author._Attributes._CoAuthorID.Contains( _coAuthorID ))
                    //            _author._Attributes._CoAuthorID.Add( _coAuthorID );

                    //    if ( !_author._Attributes._VenueID.Contains( _venueID ))
                    //        _author._Attributes._VenueID.Add( _venueID );
                    //  }   
                    // _myReader_1.Close();

                    //.....this is the code if we use the class i.e. "Paper.cs"
                    
                    while (_myReader_1.Read())
                    {
                        _Row_Counter++;

                        int _authorID   = _myReader_1.GetInt32(0);
                        Author _author  = _eAthors.FirstOrDefault(_a => _a._AuthorID == _authorID);
                        if (_author == null)
                        {
                            _author = new Author
                            {
                                 _AuthorID      = _authorID,
                                 _AuthorName    = _myReader_1.GetString(1),
                                 _Papers        = new List<Paper>()
                            };  
                            _eAthors.Add(_author); // only add if author not found
                        }  

                        int _paperID        = _myReader_1.GetInt32(2);
                        int _paperCategory  = _myReader_1.GetInt32(3);
                        int _coAuthorID     = _myReader_1.GetInt32(4);
                        int _venueID        = _myReader_1.GetInt32(5);
                        int _year           = _myReader_1.GetInt32(6);

                        Paper _paper = _author._Papers.FirstOrDefault(_a => _a._PaperID == _paperID);
                        if ( _paper == null ) 
                        {
                            _paper = new Paper
                            {
                                _PaperID        = _paperID,
                                _VenueID        = _venueID,
                                _PaperCategory  = _paperCategory,
                                _Year           = _year,
                                _CoAuthors      = new List<int>()
                            }; 
                            
                            _author._Papers.Add( _paper ); // only add if no matching Paper found
                        }
                        if ( !_paper._CoAuthors.Contains( _coAuthorID ) ) // only add if no matching CoAuthor found
                            _paper._CoAuthors.Add( _coAuthorID );
                    }
                    _myReader_1.Close();  
                 }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            _collection = _fullListAuthors.GetAuthorsBetweenYears(_eAthors, _startYear, _endYear);

        }
    }
}
