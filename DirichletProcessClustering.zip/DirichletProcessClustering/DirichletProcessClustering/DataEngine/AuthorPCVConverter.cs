﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.DataEngine;
using DirichletProcessClustering.Network;
using DirichletProcessClustering.GraphData;
using DirichletProcessClustering.Utilities;

namespace DirichletProcessClustering.DataEngine
{
    // Class that converts Author (i.e. Target Object into EvoObject, only using Paper, CoAuthor and Venue as Attributes
    // and it extends an abstract class i.e. EvoObjectConverter<T>
    public class AuthorPCVConverter : EvoObjectConverter<Author>
    {
        // Class constructor
        public AuthorPCVConverter()
        { }

        // Class constructor overridden
        public AuthorPCVConverter(List<Author> _eAuthor)
        {
            Convert(_eAuthor);
        }
        
        // Overriding method of abstract class i.e. EvoObjectConverted<T>
        public override EvoObject ConvertPCV(Author _author)
        {
            List<int> _Papers;      // First attribute

            if (!UtilCS.NullOrEmpty(_author.GetPapers())) 
            {
                _Papers = new List<int>(_author.GetPapers());
            } 
            else 
            {
                _Papers = new List<int>(); 
            }

            List<int> _CoAuthors;   // Second attribute

            if (!UtilCS.NullOrEmpty(_author.GetCoAuthors()))
            {
                _CoAuthors = new List<int>(_author.GetCoAuthors());
            }
            else
            {
                _CoAuthors = new List<int>();
            }

            List<int> _Venues;      // Third attribute

            if (!UtilCS.NullOrEmpty(_author.GetVenues()))
            {
                _Venues = new List<int>(_author.GetVenues());
            }
            else
            {
                _Venues = new List<int>();
            }

            // return new EvoObject i.e. converted form
            return new EvoObject(_author, _Papers, _CoAuthors, _Venues);
        }
    }
}
