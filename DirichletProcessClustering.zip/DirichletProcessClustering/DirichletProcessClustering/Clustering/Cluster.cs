﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.GraphData;
using DirichletProcessClustering.Network;
using DirichletProcessClustering.Utilities;

namespace DirichletProcessClustering.Clustering
{
    public class Cluster                        // Base class for clustering
    {
        protected int _clusterID = -1;          // used to represent each cluster ID
        private static int _clusterCount = 0;   // used to represent number of clusters

        protected int _attributeCount;          // number of attributes for each target object i.e. 3

        protected List<EvoObject> _clusterObjects = new List<EvoObject>();  // _clusterObjects contains EvoObjects in this cluster.

        protected Int32[] _nkA;                 // _nkA[_i] is the total occurrences of the attribute _i in this cluster
        
        // For each attribute, record their values as KeyValuePair.
        protected IDictionary<Int32, UtilCS.KeyCountMap<Int32>> _attributeValues = new Dictionary<Int32, UtilCS.KeyCountMap<Int32>>();

        // class constructor
        public Cluster(int _clusterID, int _attributeCount)
        {
            this._clusterID = _clusterID;
            this._attributeCount = _attributeCount;
            _nkA = new Int32[_attributeCount];

            var _range = Enumerable.Range(0, _attributeCount).ToList();
            _range.ForEach(_g => { _attributeValues.Add(_g, new UtilCS.KeyCountMap<int>()); });

            //for (int _i = 0; _i < _attributeCount; _i++)
            //{
            //    _attributeValues.Add(_i, new UtilCS.KeyCountMap<int>());
            //}
        }     

        public IEnumerable<Int32> GetAttributeValueKeys 
        { 
            get 
            {
                return _attributeValues.Keys;
            } 
        }            
        
        // Class constructor overridden
        public Cluster(int _attributeCount) : this(_clusterCount++, _attributeCount)
        {
            //_clusterCount = _clusterCount++;
            //this._attributeCount = _attributeCount;
        }

        public List<EvoObject> GetClusterObjects()  // Get list of clustered EvoObjects
        {
            return _clusterObjects;
        }

        public int GetClusterID()                   // Get ID of cluster
        {
            return _clusterID;
        }

        public void SetClusterID(int _v)            // Set ID of cluster
        {
            _clusterID = _v;
        }

        // nkA[i] is the total occurrences of the attribute i in this cluster
        public int GetNkA(int _index)
        {
            return _nkA[_index];
        }

        // The occurrence number of attribute value a_j (paper) in cluster k.
        public virtual int GetNkAj(int _attrIndex, int _attrVal)
        {
            int? _nkaj = GetAttributeKeyCountMap(_attrIndex).Get(_attrVal);
            if (_nkaj == null)
            {
                return 0;
            }
            else
            {
                return _nkaj.Value;
            }
        }
        
        // Get recorded values of attributes
        public UtilCS.KeyCountMap<Int32> GetAttributeKeyCountMap(int _index)
        {
            return _attributeValues[_index];
        }

        // Get size of list of clustered EvoObjects
        public int GetClusterSize()
        {
            return _clusterObjects.Count;
        }
    }
}
