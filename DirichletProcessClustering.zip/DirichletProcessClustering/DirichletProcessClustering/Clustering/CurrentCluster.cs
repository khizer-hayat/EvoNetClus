﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using DirichletProcessClustering.Network;

namespace DirichletProcessClustering.Clustering
{
    public class CurrentCluster : Cluster           // Derived class from the base class i.e. Cluster.cs
    {
        // _netaK is only used by CurrentCluster. It's the cluster proportion coefficient.
        private double _etak = 0;

        // Class constructor
        public CurrentCluster(int _clusterID, int _attributeCount) : base(_clusterID, _attributeCount)
		{
		}

        // Class constructor overridden
		public CurrentCluster(int _attributeCount) : base(_attributeCount)
		{
		}

        //  add this object to Cluster's _clusterObjects, and assign this cluster to object's currentCluster. */
        public void AssignCurrentCluster(EvoObject _eObject)
        {
            _clusterObjects.Add(_eObject);
            _eObject.SetCurrentCluster(this);

            for (int _i = 0; _i < _attributeCount; _i++)
            {
                if (_eObject.GetAttribute(_i) != null)
                {
                    // update _nkA
                    _nkA[_i] += _eObject.GetAttribute(_i).Count();
                    // update _attributeValues
                    _attributeValues[_i].AddCount(_eObject.GetAttribute(_i));
                }
            }
            // update prior group's _njk
            _eObject.GetPriorGroup().AddNjk(_eObject.GetCurrentCluster().GetClusterID());
        }

        // remove this object from cluster's _clusterObjects, and assign null to object's currentCluster.
        public void UnassignCurrentCluster(EvoObject _eObject) 
        {
            Debug.Assert(_clusterObjects.Remove(_eObject));

            for (int _i = 0; _i < _attributeCount; _i++)
            {
                if (_eObject.GetAttribute(_i) != null)
                {
                    // update _nkA
                    _nkA[_i] -= _eObject.GetAttribute(_i).Count();
                    // update _attributeValues
                    _attributeValues[_i].DisCount(_eObject.GetAttribute(_i));
                }
            }
            // update prior group's _njk
            _eObject.GetPriorGroup().DecNjk(_eObject.GetCurrentCluster().GetClusterID());
            _eObject.SetCurrentCluster(null);
        }

        // _netaK is only used by CurrrentCluster. It's the cluster proportion coefficient.*/
        public double GetEtaK()
        {
            return _etak;
        }

        // _netaK is only used by CurrentCluster. It's the cluster proportion coefficient.*/
        public void SetEtaK(double _value)
        {
            _etak = _value;
        }
    }
}
