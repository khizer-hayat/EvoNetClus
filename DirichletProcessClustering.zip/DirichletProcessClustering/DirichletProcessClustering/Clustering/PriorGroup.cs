﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.GraphData;
using DirichletProcessClustering.Network;
using DirichletProcessClustering.Utilities;

namespace DirichletProcessClustering.Clustering
{
    public class PriorGroup : Cluster
    {
        //  _njk is only used if this cluster is used as prior group.
        //  _njk is the number of objects in this prior group belonging to cluster k. 
        private UtilCS.KeyCountMap<Int32> _njk = new UtilCS.KeyCountMap<Int32>();

        //  _mjk is only used if this cluster is used as prior group.
        //  _mjk is the number of micro clusters in this prior group that belong to cluster k.
        private IDictionary<Int32, Double> _mjk = new Dictionary<Int32, Double>();

        //  Class constructor
        public PriorGroup(int _clusterID, int _attributeCount) : base(_clusterID, _attributeCount)
        {
            //_clusterID = base._clusterID;
            //_attributeCount = base._attributeCount;
        }

        //  Class constructor overridden
        public PriorGroup(int _attributeCount) : base(_attributeCount)
        {
            //_attributeCount = base._attributeCount;
        }

        // add this object to cluster's _clusterObjects, and assign priorId to object's priorgroupid. */
        public void AssignPrior(EvoObject _eObject)
        {
            _clusterObjects.Add(_eObject);
            _eObject.SetPriorGroup(this);

            for (int _i = 0; _i < _attributeCount; _i++)
            {
                if (_eObject.GetAttribute(_i) != null)
                {
                    // update nkA
                    _nkA[_i] += _eObject.GetAttribute(_i).Count;
                    // update attrValues
                    _attributeValues[_i].AddCount(_eObject.GetAttribute(_i));
                }
            }
        }
        // _njk is only used if this cluster is used as prior group.
        // _njk is the number of objects in this prior group belonging to cluster k.
        public UtilCS.KeyCountMap<Int32> GetNjk()
        {
            return _njk;
        }

        // increase _njk by 1 with specified k.
        // _njk is only used if this cluster is used as prior group.
        // _njk is the number of objects in this prior group belonging to cluster k.
        public void AddNjk(int _k)
        {
            GetNjk().AddCount(_k);
        }

        // decrease _njk by 1 with specified k.
        // _njk is only used if this cluster is used as prior group.
        // _njk is the number of objects in this prior group belonging to cluster k.
        public void DecNjk(int _k)
        {
            GetNjk().DisCount(_k);
        }

        // _njk is only used if this cluster is used as prior group.
        // _njk is the number of objects in this prior group belonging to cluster k.
        public Int32 GetNjk(int _k)
        {
            int? _njkResult = _njk.Get(_k);
            if (_njkResult == null)
            {
                return 0;
            }
            else
            {
                return _njkResult.Value;
            }
        }

        // Get Mjk value
        public double GetMjk(int _k)
        { 
            double _mjkResult;
            if (_mjk.TryGetValue(_k, out _mjkResult))
            {
                return _mjkResult;
            }
            
            return 0;
        }

        // Set Mjk value
        public void SetMjk(int _k, double _value)
        {
            _mjk[_k] = _value;
        }
    }
}
