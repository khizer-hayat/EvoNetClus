﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using DirichletProcessClustering.Clustering;


namespace DirichletProcessClustering.Utilities
{
    // A utility class used for defining some custom methods used in the code.
    public class UtilCS
    {
        /** Return true if two arrays are the same. */
        public static Boolean compateTwoArrays(string[] _a, string[] _b)
        {
            if (_a.Length != _b.Length)
            {
                return false;
            }
           
            for (int _i = 0; _i < _a.Length; _i++) 
            {
                if (!_a[_i].Equals(_b[_i]))
                {
                    return false;
                }
            }
            return true;
        }

        // Return Max of 'n' values
        public static Int32 GetMax(List<Int32> _values)
        {
            int _max = 0;

            for(int _i = 0; _i < _values.Count; _i++)
            {
                if(_values[_i] > _max)
                {
                    _max = _values[_i];
                }
            }
            return _max;
        }

        public class KeyCountMap<T>// where T : new()
        { 

            private IDictionary<T, MutableInt> _map = new Dictionary<T, MutableInt>();

            internal int _totalCount = 0;

            //JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
            //ORIGINAL LINE: @SuppressWarnings({ "unchecked", "rawtypes" }) public KeyCountMap(Class mapType) throws InstantiationException, IllegalAccessException
            //JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:

            public KeyCountMap()
            { }

            public KeyCountMap(Type _dictionaryType)
            {
                if (!typeof(IDictionary<T, MutableInt>).IsAssignableFrom(_dictionaryType))
                {
                    throw new ArgumentException("Type must be a IDictionary<T, MutableInt>", "_dictionaryType");
                }
                _map = (SortedDictionary<T, MutableInt>)Activator.CreateInstance(_dictionaryType);
            }

            
            //public KeyCountMap(T _obj)
            //{
            //    _obj = new T();
            //    _map = (Dictionary<T, MutableInt>)(object)_obj;
            //}
                
            public void AddCount(T _key)
            {
                MutableInt _count;
                if ( _map.TryGetValue(_key, out _count) )
                {
                    _count = _map[_key];
                    _count.Increment();
                }
                else
                {
                   _map[_key] = new MutableInt();
                }
                _totalCount++;
             }

            public void AddCount(IList<T> _c)
            {
                foreach (T _key in _c)
                {
                    AddCount(_key);
                }
            }

            public void DisCount(T _key)
            {
                MutableInt _count;
                if (_map.TryGetValue(_key, out _count))
                {
                    _count = _map[_key];
                    if (_count.Get() == 1)
                    {
                        _map.Remove(_key);
                    }
                    else
                    {
                        _count.Discrement();
                    }
                }
                _totalCount--;
            }
            
            public void DisCount(ICollection<T> _c)
            {
                foreach (T _key in _c)
                {
                    DisCount(_key);
                }
            }
            
            public void Put(T _key, MutableInt _mi)
            {
                _map[_key] = _mi;
                _totalCount += (int)_mi.Get();
            }

            public void Remove(T _key)
            {
                _totalCount -= (int)_map[_key].Get();
                _map.Remove(_key);
            }

            public int? Get(T _key)
            {
                MutableInt _v;
                if (_map.TryGetValue(_key, out _v))
                {
                    return _map[_key].Get();
                }
                return null;
            }
            
            public virtual ICollection<T> KeySet() 
            {
                return _map.Keys;
            }

           /*public ISet<KeyValuePair<T, MutableInt>> EntrySet()
            {
                return new HashSet<KeyValuePair<T, MutableInt>>(_map);
            }*/

            public HashSet<KeyValuePair<T, MutableInt>> EntrySet()
            {
                return _map.ToSet();
            }

            public virtual bool Contains(T _key)
            {
                return _map[_key] != null;
            }

            public virtual int Size()
            {
                return KeySet().Count;
            }

            // Get the sum of values in KeyCountMap. </summary>
            public virtual int TotalCount
            {
                get
                {
                    return _totalCount;
                }
            }
        }

        // Class for KeyCountMap.

        public class MutableInt : IComparable<MutableInt>
        {
            int _value = 1; // note that we start at 1 since we're counting

            public int CompareTo(MutableInt _other)
            {
                return (null == _other) ? 1 : _value.CompareTo(_other._value);
            } 

            public void Increment()
            {
                _value++;
            }

            public void Discrement()
            {
                _value--;
            }

            public int? Get()
            {
                return _value;
            }
        }

        // Return true if there integer is null or empty ("").
        public static bool NullOrEmpty(Int32 _s)
        {
            if (Int32.ReferenceEquals(_s, null))
            {
                return true;
            }

            if (_s.Equals(""))
            {
                return true;
            }
            return false;
        }

        // Return true if the string is null or empty ("").
        public static bool NullOrEmpty(string _s)
        {
            if (string.ReferenceEquals(_s, null))
            {
                return true;
            }

            if (_s.Equals(""))
            {
                return true;
            }
            return false;
        }

        // Return true if object is null
        public static bool NullOrEmpty(Object _o)
        {
            if (_o == null)
            {
                return true;
            }
            return false;
        }

        // If the strings contained in the collection are either null or empty.
        // @param <T> </param>
        public static bool NullOrEmpty(ICollection<string> _list)
        {
            if (_list == null)
            {
                return true;
            }

            if (_list.Count == 0)
            {
                return true;
            }

            if (_list.Count >= 1)
            {
                foreach (string _o in _list)
                {
                    if (!NullOrEmpty(_o))
                    {
                        return false;
                    }
                }
                return true;
            }

            // never return to this
            return false;
        }
        
        // If the integers contained in the collection are either null or empty.
        // @param <T> </param>
        public static bool NullOrEmpty(ICollection<Int32> _list)
        {
            if (_list == null)
            {
                return true;
            }

            if (_list.Count == 0)
            {
                return true;
            }

            if (_list.Count >= 1)
            {
                foreach (Int32 _o in _list)
                {
                    if (!NullOrEmpty(_o))
                    {
                        return false;
                    }
                }
                return true;
            }

            // never return to this
            return false;
        }

        // Return the index of the maximum in the double array
        public static int IndexOfMax(double[] _arr)
        {
            double _max = 0 - double.MaxValue;
            int _index = 0;
            for (int _i = 0; _i < _arr.Length; _i++)
            {
                if (_arr[_i] > _max)
                {
                    _max = _arr[_i];
                    _index = _i;
                }
            }
            return _index;
        }

        // Return the index of the maximum in the integer array
        public static int IndexOfMax(int[] _arr)
        {
            int _max = 0 - int.MaxValue;
            int _index = 0;
            for (int _i = 0; _i < _arr.Length; _i++)
            {
                if (_arr[_i] > _max)
                {
                    _max = _arr[_i];
                    _index = _i;
                }
            }
            return _index;
        }
        
        // Return the index of maximum in the array
        /*public static int IndexOfMax<T>(IList<T> mList, Field field)
        {
            double max = 0 - double.MaxValue;
            int index = 0;
            for (int i = 0; i < mList.Count; i++)
            {
                double? value = (double?)field.get(mList[i]);
                if (value > max)
                {
                    max = value.Value;
                    index = i;
                }
            }
            return index;
        }*/

        // Sort KeyCountMap's keyset by values and return a new KeyCountMap. </summary>
        // @param <T> </param>
        public static KeyCountMap<T> SortMapByDescendValue<T>(KeyCountMap<T> _map)
        {
            List<KeyValuePair<T, MutableInt>> _list = new List<KeyValuePair<T, MutableInt>>(_map.EntrySet());

            _list = _list.OrderByDescending(_x => _x.Value).ToList();

            KeyCountMap<T> _result = new KeyCountMap<T>();
            foreach (KeyValuePair<T, MutableInt> _entry in _list)
            {
                _result.Put(_entry.Key, _entry.Value);
                
            }
            return _result; 
        }
    }   
}
