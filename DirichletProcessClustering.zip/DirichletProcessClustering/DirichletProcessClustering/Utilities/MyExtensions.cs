﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirichletProcessClustering.Utilities
{
    // A class for defining some extension methods
    public static class MyExtensions
    {
        // return all KeyValuePair in a dictionary into a Set form.
        public static HashSet<KeyValuePair<TKey, TValue>> ToSet<TKey, TValue>(this IDictionary<TKey, TValue> _dict)
        {
            return new HashSet<KeyValuePair<TKey, TValue>>(_dict.ToList());
        }

        // Uppercase the first letter in the string.
        public static string UppercaseFirstLetter(this string _value)
        {
            if (_value.Length > 0)
            {
                char[] _array = _value.ToCharArray();
                _array[0] = char.ToUpper(_array[0]);
                return new string(_array);
            }
            return _value;
        }

        // Sort dictionary by descending order of TValue.
        public static Dictionary<TKey, TValue> SortByValueDescending<TKey, TValue>(Dictionary<TKey, TValue> _map)
        {
            Dictionary<TKey, TValue> _result = new Dictionary<TKey, TValue>();
            
            // Use LINQ to specify sorting by value.
            var _items = from _pair in _map
                         orderby _pair.Value descending
                         select _pair;
            // Display results.
            foreach (KeyValuePair<TKey, TValue> _pair in _items)
            {
                _result.Add(_pair.Key, _pair.Value);
                //Console.WriteLine("{0}: {1}", _pair.Key, _pair.Value);
            }
            return _result;
        }
        
        // Shuffles a generic List.
        public static List<T> Shuffle<T>(this IList<T> _list)
        {
            Random _random = new Random();
            int _n = _list.Count;
            for (int _i = 0; _i < _n; _i++)
            {
                // NextDouble returns a random number between 0 and 1.
                // ... It is equivalent to Math.random() in Java.
                int _r = _i + (int)(_random.NextDouble() * (_n - _i));
                T _value = _list[_r];
                _list[_r] = _list[_i];
                _list[_i] = _value;
            }
            return _list.ToList();
        }

        // Returns distinct elements from a generic List.
        //public static List<T> GetDistinct(this IList<T> _list)
        //{
            
        //    for (int _i = 0; _i < _list.Count - 1; _i++)
        //    {
        //        for (int _j = 1; _j < _list.Count; _j++)
        //        {
        //            T 
        //        }
        //    }
        //}
    }
}
