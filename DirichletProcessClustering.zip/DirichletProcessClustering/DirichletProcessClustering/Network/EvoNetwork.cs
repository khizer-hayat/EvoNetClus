﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using DirichletProcessClustering.Clustering;
using DirichletProcessClustering.DataEngine;
using DirichletProcessClustering.Utilities;

namespace DirichletProcessClustering.Network
{
    // Main class for EvoNetwork whereas Build() is the main acting method calling other sub methods
    public class EvoNetwork<T>
    {
        // EvoNetwork class properties
        private int _startYear;
        private int _endYear;
        private int _timeStep;
        private int _attributeCount;

        private double _alpha;
        private double[] _beta;
        private double _lambda;
        private double _gamma;
        private int[] _attributeSizes;

        // EvoNetwork class Constructor
        public EvoNetwork(int _sYear, int _eYear, int _tStep, int _aCount, double _a, double[] _b, double _l, double _g, int[] _aSize) 
        {
            Debug.Assert(_b.Length == _aCount);
            Debug.Assert(_aSize.Length == _aCount);

            _startYear = _sYear;
            _endYear = _eYear;
            _timeStep = _tStep;
            _attributeCount = _aCount;
                    
            _alpha = _a;
            _beta = _b;
            _lambda = _l;
            _gamma = _g;
            _attributeSizes = _aSize;
        }

        // param iterations maximal iterations for gibbs sampling within one time slice
        public Tuple<List<List<PriorGroup>>, List<List<CurrentCluster>>> Build(EvoObjectCollector<T> _eCollector, EvoObjectConverter<T> _eConverter, int _iterations)
        {
            List<List<CurrentCluster>> _currentClustersList = new List<List<CurrentCluster>>();
            List<List<PriorGroup>> _priorGroupsList = new List<List<PriorGroup>>();

            List<CurrentCluster> _previousClusters = null;

            for (int _year = _startYear; _year <= _endYear; _year += _timeStep)
            {
                // collect raw objects and then convert to EvoObjects
                _eCollector.Collect(_year, _year + _timeStep - 1);
                List<T> _eRawObjects = _eCollector.GetCurrentCollection();
                _eConverter.Convert(_eRawObjects);
                List<EvoObject> _eEvoObjects = _eConverter.GetCurrentConversion();
                
                // Assign prior groups to EvoObjects
                List<PriorGroup> _priorGroups = AssignPriorGroups(_eEvoObjects, _previousClusters);
                
                // Assign current clusters to EvoObjects
                List<CurrentCluster> _currentClusters = AssignCurrentClusters(_priorGroups, _eEvoObjects, _previousClusters, _iterations);
                _previousClusters = _currentClusters;
            
                _priorGroupsList.Add(_priorGroups);
                _currentClustersList.Add(_currentClusters);
            
                Console.WriteLine("Year " + _year + " finished");   // Notify on console when one time slice expires
            }

            Console.ReadLine();
        
            return new Tuple<List<List<PriorGroup>>, List<List<CurrentCluster>>>(_priorGroupsList, _currentClustersList);
        }

        // Assign prior groups according to previous clusters. 
        private List<PriorGroup> AssignPriorGroups(List<EvoObject> _eObjects, List<CurrentCluster> _previousClusters) 
        {
            List<PriorGroup> _priorGroups = new List<PriorGroup>();
        
            // first year
            if (_previousClusters == null) 
            {
                PriorGroup _firstPriorGroup = new PriorGroup(_attributeCount);
                // assign all authors to this cluster
                foreach (EvoObject _eObject in _eObjects)
                {
                    _firstPriorGroup.AssignPrior(_eObject);
                }
                _priorGroups.Add(_firstPriorGroup);
            }
            else 
            {
                // create a list of prior groups that have the same _clusterID as previous clusters
                foreach (CurrentCluster _previousCluster in _previousClusters) 
                {
                    PriorGroup priorGroup = new PriorGroup(_previousCluster.GetClusterID(), _attributeCount);
                    _priorGroups.Add(priorGroup);
                }
                _priorGroups.Add(new PriorGroup(_attributeCount));
            
                foreach (EvoObject _eEvoObject in _eObjects) 
                {
                    // one more for new prior group
                    double[] _p = new double[_previousClusters.Count() + 1];
                
                    for (int _k = 0; _k < _previousClusters.Count(); _k++) 
                    {
                        CurrentCluster _kCluster = _previousClusters[_k]; 
                        double _fkMinusOjiLn = CalcFkMinusOjiln(_kCluster, _eEvoObject, false);
                        _p[_k] = _fkMinusOjiLn + Math.Log(Convert.ToDouble(_kCluster.GetClusterSize())); 
                    }

                    double _fkNewLn = CalcFknewLn(_eEvoObject);
                    _p[_p.Length - 1] = _fkNewLn + Math.Log(_gamma);
                
                    int _clsAssignIndex = UtilCS.IndexOfMax(_p);
                    _priorGroups[_clsAssignIndex].AssignPrior(_eEvoObject);
                }
            } // following years
        
            return _priorGroups;
        }

        // Assign current clusters according to priorGroups
        private List<CurrentCluster> AssignCurrentClusters(List<PriorGroup> _priorGroups, List<EvoObject> _eEvoObjects, List<CurrentCluster> _prevClusters, int _iterations)
        {
            List<CurrentCluster> _curClusters = InitCurClsFromPriorGrps(_priorGroups);

            // mSum, used for calculating _etak
            double _mSum = 0;
            // _etau is initialized as 1. 
            double _etau = 1;
            // the total number of authors from time slice t-1
            int _Ntminus1Sum = _priorGroups.ToArray().Select(_b => _b.GetClusterSize()).Sum();

            // Iterate over many times for collapsed Gibbs sampling
            for (int _iteration = 0; _iteration < _iterations; _iteration++)
            {
                // indicate whether at least object has changed cluster assignment
                bool _changed = false;
                // At each iteration, the target objects are randomly shuffled for a new order.
                _eEvoObjects.Shuffle();

                for (int _i = 0; _i < _eEvoObjects.Count; _i++)
                {
                    EvoObject _eEvoObject = _eEvoObjects[_i];

                    // p holds the probability that _eEvoObject belongs to each current cluster
                    // one more probability for new cluster
                    double[] _p = new double[_curClusters.Count + 1];

                    PriorGroup _jPriorGrp = _eEvoObject.GetPriorGroup();

                    // traverse current clusters to calculate the probability of belongingness
                    for (int _k = 0; _k < _curClusters.Count; _k++)
                    {
                        CurrentCluster _kCluster = _curClusters[_k];

                        // n_{jk}^{-ji} denotes the number of objects in group j belonging to cluster k without considering object o_{ji}
                        int _njkMinusji = CalcNjkMinusji(_jPriorGrp, _kCluster, _eEvoObject);
                        double _etaK = _kCluster.GetEtaK();
                        double _fkMinusOjiLn = CalcFkMinusOjiln(_kCluster, _eEvoObject, _kCluster == _eEvoObject.GetCurrentCluster());

                        if (FromKTMinus1(_kCluster, _prevClusters))
                        {
                            // n_{t-1,k} is the size of k cluster from previous time slice. 
                            // here jCluster (from priorGroups) has the same _clusterID as k cluster (from curClusters) 
                            int _ntMinus1k = _jPriorGrp.GetClusterSize();
                            _p[_k] = CalProbInKtMinus1Ln(_njkMinusji, _etaK, _ntMinus1k * 1.0 / _Ntminus1Sum, _fkMinusOjiLn);
                        }
                        else
                        {
                            _p[_k] = CalcProbNotInKtMinus1Ln(_njkMinusji, _etaK, _fkMinusOjiLn);
                        }
                        Console.Write("ClusterID = {0} : {1} \n", _kCluster.GetClusterID(), _fkMinusOjiLn);
                    }

                    double _fknewLn = CalcFknewLn(_eEvoObject);
                    _p[_p.Length - 1] = CalcProbNewLn(_etau, _fknewLn);
                    Console.WriteLine("fnew:" + _fknewLn);

                    CurrentCluster _newClsAssign = GetClsAssignment(_p, _curClusters);

                    PrintInfo(_iteration, _i, _eEvoObject, _p, _curClusters, _newClsAssign, _mSum);

                    // If cluster assignment is changed for _eEvoObject, update cluster information
                    if (_newClsAssign != _eEvoObject.GetCurrentCluster())
                    {
                        _changed = true;

                        CurrentCluster _oldClsAssign = _eEvoObject.GetCurrentCluster();
                        // if _oldClsAssign == null, that means _eEvoObject hasn't been assigned to any cluster in this timeframe.
                        // i.e. this is in the first iteration
                        if (_oldClsAssign != null)
                        {
                            _oldClsAssign.UnassignCurrentCluster(_eEvoObject);
                        }

                        _newClsAssign.AssignCurrentCluster(_eEvoObject);

                        _mSum = UpdateMjk(_jPriorGrp, _newClsAssign, _oldClsAssign, _mSum);
                        UpdateEtaK(_priorGroups, _newClsAssign, _oldClsAssign, _mSum);
                        _etau = UpdateEtau(_mSum);

                        // remove old cluster if it is empty
                        if (_oldClsAssign != null && _oldClsAssign.GetClusterSize() == 0)
                        {
                            _curClusters.Remove(_oldClsAssign);
                        }

                        // add new cluster to current cluster list
                        if (!_curClusters.Contains(_newClsAssign))
                        {
                            _curClusters.Add(_newClsAssign);
                        }
                    }

                    Console.WriteLine();
                } // traverse all objects

                // If no cluster assignment is changed, stop iterations.
                if (!_changed)
                {
                    break;
                }

            } // all iterations

            // Final check if there is empty cluster
            //JAVA TO C# CONVERTER WARNING: Unlike Java's ListIterator, enumerators in .NET do not allow altering the collection:
            
            // Removing all cluster from _curClusters having cluster size = 0
            _curClusters.RemoveAll(_curClus => _curClus.GetClusterSize() == 0);

            // Now _curClusters will only contain "sized clusters" i.e. cluster having size > 0
            //_curClusters = _curClusters.Where(_c => _c.GetClusterSize() > 0).ToList();

            // Doing same using iteration
            //var _toBeRemoved = new List<CurrentCluster>();

            //foreach (var _suspiciousCluster in _curClusters)
            //{
            //    if (_suspiciousCluster.GetClusterSize() == 0)
            //    {
            //        _toBeRemoved.Add(_suspiciousCluster);
            //    }
            //}

            //foreach (var _voidCluster in _toBeRemoved)
            //{
            //    _curClusters.Remove(_voidCluster);
            //}

            return _curClusters;
        }
        
        
        private double UpdateEtau(double _mSum)
        {
            double _result = _gamma / (_mSum + _gamma);
            Console.WriteLine("eta_u updated to " + _result);
            return _result;
        }
        
        private void UpdateEtaK(List<PriorGroup> _priorGroups, CurrentCluster _newClsAssign, CurrentCluster _oldClsAssign, double _mSum)
        {
            double _mk = 0;
            int _k = _newClsAssign.GetClusterID();
            foreach (PriorGroup _priorGrp in _priorGroups)
            {
                double _mjk = _priorGrp.GetMjk(_k);
                if (double.IsNaN(_mjk))
                {
                    Console.WriteLine("Debug");
                }
                _mk += _mjk;
            }
            double _etaK = _mk / (_mSum + _gamma);
            Console.Write("Set eta {0} from {1} to {2}, mk = {3} \n", _k, _newClsAssign.GetEtaK(), _etaK, _mk);
            _newClsAssign.SetEtaK(_etaK);

            if (_oldClsAssign != null)
            {
                double _mkOld = 0;
                int _kOld = _oldClsAssign.GetClusterID();
                foreach (PriorGroup _priorGrp in _priorGroups)
                {
                    _mkOld += _priorGrp.GetMjk(_kOld);
                }
                double _etaKold = _mkOld / (_mSum + _gamma);
                _oldClsAssign.SetEtaK(_etaKold);
            }
        }

        // update mjk associating with newCls and oldCls.
        private double UpdateMjk(PriorGroup _jPriorGroup, CurrentCluster _newClsAssign, CurrentCluster _oldClsAssign, double _mSum)
        {
            if (_jPriorGroup.GetMjk(_newClsAssign.GetClusterID()) == 0)
            {
                _jPriorGroup.SetMjk(_newClsAssign.GetClusterID(), 1);
                Console.Write("Create m_{{{0},{1}}} = {2}\n", _jPriorGroup.GetClusterID(), _newClsAssign.GetClusterID(), _jPriorGroup.GetMjk(_newClsAssign.GetClusterID()));
                _mSum = _mSum + 1;
            }
            else
            {
                int _k = _newClsAssign.GetClusterID();
                double _etaK = _newClsAssign.GetEtaK();
                double _newMjk = _alpha * _etaK * Math.Log(1 + _jPriorGroup.GetNjk(_k) / (_alpha * _etaK));
                Console.Write("Change m_{{{0},{1}}} from {2} ", _jPriorGroup.GetClusterID(), _newClsAssign.GetClusterID(), _jPriorGroup.GetMjk(_k));
                _mSum -= _jPriorGroup.GetMjk(_k);
                _jPriorGroup.SetMjk(_newClsAssign.GetClusterID(), _newMjk);
                _mSum += _jPriorGroup.GetMjk(_k);
                Console.Write("to {0}, etaK: {1}, njk: {2} \n", _jPriorGroup.GetMjk(_k), _etaK, _jPriorGroup.GetNjk(_k));
            }

            if (_oldClsAssign != null)
            {
                int _kOld = _oldClsAssign.GetClusterID();
                double _etaKOld = _oldClsAssign.GetEtaK();
                double _newMjkOld = _alpha * _etaKOld * Math.Log(1 + _jPriorGroup.GetNjk(_kOld) / (_alpha * _etaKOld));
                if (double.IsNaN(_newMjkOld))
                {
                    Console.WriteLine("Debug");
                }
                _mSum -= _jPriorGroup.GetMjk(_kOld);
                _jPriorGroup.SetMjk(_oldClsAssign.GetClusterID(), _newMjkOld);
                _mSum += _jPriorGroup.GetMjk(_kOld);
            }
            Console.WriteLine("mSum after update _mjk:" + _mSum);
            
            return _mSum;
        }

        private void PrintInfo(int _iteration, int _i, EvoObject _eEvoObject, double[] _p, List<CurrentCluster> _curClusters, CurrentCluster _newClsAssign, double _mSum)
        {
            if (_eEvoObject.GetCurrentCluster() == null)
            {
                Console.Write("Iteration: {0}, EvoObj {1}: from null to {2}\n", _iteration, _i, _newClsAssign.GetClusterID());
            }
            else
            {
                Console.Write("Iteration: {0}, EvoObj {1}: from {2} to {3} \n", _iteration, _i, _eEvoObject.GetCurrentCluster().GetClusterID(), _newClsAssign.GetClusterID());
            }

            for (int _a = 0; _a < _attributeCount; _a++)
            {
                Console.WriteLine(_eEvoObject.GetAttribute(_a));
            }

            Console.Write("p:    ");
            
            foreach (double _pk in _p)
            {
                Console.Write("{0}\t", _pk);
            }
            
            Console.WriteLine();
            Console.Write("ClusterID:\t");
            foreach (CurrentCluster _cls in _curClusters)
            {
                Console.Write("\t" + _cls.GetClusterID() + "\t");
            }
            
            Console.WriteLine();
            Console.Write("ClusterSize:");
            foreach (CurrentCluster _cls in _curClusters)
            {
                Console.Write("\t" + _cls.GetClusterSize() + "\t");
            }
            Console.WriteLine();
        }

        private CurrentCluster GetClsAssignment(double[] _p, List<CurrentCluster> _curClusters)
        {
            Debug.Assert(_p.Length == _curClusters.Count + 1);

            // greedy assignment
            int _sampleIndex = UtilCS.IndexOfMax(_p);

            // sample as new cluster
            if (_sampleIndex == _curClusters.Count)
            {
                return new CurrentCluster(_attributeCount);
            }
            else
            {
                for (int k = 0; k < _curClusters.Count; k++)
                {
                    if (k == _sampleIndex)
                    {
                        return _curClusters[k];
                    }
                }
            }

            //never reach here
            Debug.Assert(false);
            return null;
        }

        private double CalcProbNewLn(double _etau, double _fknewLn)
        {
            Console.Write("CalcProbNewLn:  _alpha *_etau = " + (_alpha * _etau) + "\t");
            return Math.Log(_alpha * _etau) + _fknewLn;
        }

        private double CalcProbNotInKtMinus1Ln(int _njkMinusji, double _etaK, double _fkMinusOjiLn)
        {
            Console.Write("Calc Prob Not in Kt-1:  n_jk^-ji = {0}, _alpha * _etaK = {1} \t", _njkMinusji, (_alpha * _etaK));
            double _firstComponent = _njkMinusji + _alpha * _etaK;
            if (_firstComponent == 0)
            {
                return -double.MaxValue;
            }
            return Math.Log(_firstComponent) + _fkMinusOjiLn;
        }

        private double CalProbInKtMinus1Ln(int _njkMinusji, double _etaK, double _nTminus1KRatio, double _fkMinusOjiLn)
        {
            Console.Write("Calc Prob in Kt-1: n_jk^-ji = {0}, _lambda*nt-1ratio = {1}, alpha * etaK = {2} \t", _njkMinusji, (_lambda * _nTminus1KRatio), (_alpha * _etaK));
            double _firstComponent = _njkMinusji + _lambda * _nTminus1KRatio + _alpha * _etaK;
            if (_firstComponent == 0)
            {
                return -double.MaxValue;
            }
            return Math.Log(_firstComponent) + _fkMinusOjiLn;
        }

        // Check if this cluster is from {K_{t-1}}.
        private bool FromKTMinus1(CurrentCluster _kCluster, List<CurrentCluster> _prevClusters)
        {
            if (_prevClusters == null)
            {
                return false;
            }

            foreach (CurrentCluster _prevCluster in _prevClusters)
            {
                if (_kCluster.GetClusterID() == _prevCluster.GetClusterID())
                {
                    return true;
                }
            }
            return false;
        }
        
        // n_{jk}^{-ji} denotes the number of objects in group j belonging to cluster k without considering object o_{ji}
        // <param name="jPriorGroup"> _eEvoObject's prior group </param>
        // <param name="kCluster"> current cluster candidate </param>
        private int CalcNjkMinusji(PriorGroup _jPriorGroup, CurrentCluster _kCluster, EvoObject _eEvoObject)
        {
            int _njk = _jPriorGroup.GetNjk(_kCluster.GetClusterID());
            int _njkMinusji = _njk;
            if (_kCluster == _eEvoObject.GetCurrentCluster())
            {
                _njkMinusji--;
            }
            return _njkMinusji;
        }

        // Before cluster assignment step, initialize current clusters so that each current cluster corresponds to each prior group.
        private List<CurrentCluster> InitCurClsFromPriorGrps(List<PriorGroup> _priorGroups)
        {
            List<CurrentCluster> _curClusters = new List<CurrentCluster>();
            foreach (PriorGroup _priorGrp in _priorGroups)
            {
                _curClusters.Add(new CurrentCluster(_priorGrp.GetClusterID(), _attributeCount));
            }
            return _curClusters;
        }

        /// calculate f_k^{-o_{ji}}(o_{ji}) in log_e </summary>
        private double CalcFkMinusOjiln(CurrentCluster _kCluster, EvoObject _eEvoObject, bool _inThisCluster)
        {
            double _fLogeSum = 0;

            for (int _i = 0; _i < _attributeCount; _i++)
            {
                double _fkAiMinusAiln = 0;

                int _nkA = _kCluster.GetNkA(_i);
                
                // n_{k,A}^{-i} is the total occurrences of papers in cluster k without considering author o_i
                int _nkAMinusi = _nkA;
                if (_inThisCluster && _eEvoObject.GetAttribute(_i) != null)
                {
                    _nkAMinusi -= _eEvoObject.GetAttribute(_i).Count();
                }

                // |A|
                int _ASize = _attributeSizes[_i];
                double _betaA = _beta[_i];

                // n_{a_i} is the number of papers for author o_i
                int _nai = 0;
                if (_eEvoObject.GetAttribute(_i) != null)
                {
                    _nai = _eEvoObject.GetAttribute(_i).Count();
                }

                _fkAiMinusAiln += SpecialFunction.lgamma(_betaA * _ASize + _nkAMinusi);
                _fkAiMinusAiln -= SpecialFunction.lgamma(_betaA * _ASize + _nai + _nkAMinusi);
                
                if (!UtilCS.NullOrEmpty(_eEvoObject.GetAttribute(_i)))
                {
                    foreach (Int32 _attrVal in _eEvoObject.GetAttribute(_i))
                    {
                        // the occurrence number of attr value a_j in cluster
                        int _nkAj = _kCluster.GetNkAj(_i, _attrVal);
                        // n_{k,A}^{-i}(j) is the occurrence number of attr a_j in cluster k without considering o_i
                        int _nkAjMinusi = _nkAj;
                        if (_inThisCluster)
                        {
                            _nkAjMinusi--;
                        }

                        // naij indicates whether a_j have author o_i
                        int _naij = 1;
                        _fkAiMinusAiln += SpecialFunction.lgamma(_betaA + _naij + _nkAjMinusi);
                        _fkAiMinusAiln -= SpecialFunction.lgamma(_betaA + _nkAjMinusi);
                    }
                }

                _fLogeSum += _fkAiMinusAiln;
            } // traverse all attribute
            return _fLogeSum;
        }

   		private double CalcFknewLn(EvoObject _eEvoObject)
		{
			double _fkNewSumLn = 0;
			for (int _i = 0; _i < _attributeCount; _i++)
			{
				double _fkNewLn = 0;
				double _betaA = _beta[_i];

				// n_{a_i} is the number of authors for paper o_i
				int _nai = 0;
				if (!UtilCS.NullOrEmpty(_eEvoObject.GetAttribute(_i)))
				{
					_nai = _eEvoObject.GetAttribute(_i).Count;
				}

				int _ASize = _attributeSizes[_i];
				_fkNewLn += SpecialFunction.lgamma(_betaA * _ASize);
				_fkNewLn -= SpecialFunction.lgamma(_betaA * _ASize + _nai);

				if (!UtilCS.NullOrEmpty(_eEvoObject.GetAttribute(_i)))
				{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: for (@SuppressWarnings("unused") String attrVal : mEvoObject.getAttr(i))
					foreach ( int _attrVal in _eEvoObject.GetAttribute(_i) )
					{
						// _naij indicates whether a_j have author o_i
						int _naij = 1;
                        _fkNewLn += SpecialFunction.lgamma(_betaA + _naij);
						_fkNewLn -= SpecialFunction.lgamma(_betaA);
					}
				}

				_fkNewSumLn += _fkNewLn;
			} // traverse all attributes

			return _fkNewSumLn;
		}
    }
}
