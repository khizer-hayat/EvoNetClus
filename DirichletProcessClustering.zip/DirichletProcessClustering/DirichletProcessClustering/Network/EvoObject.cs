﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.Clustering;
using System.Diagnostics;
using DirichletProcessClustering.Utilities;
using System.Collections;

namespace DirichletProcessClustering.Network
{
    // Standard object for EvoNetwork
    public class EvoObject
    {
        // Standard object for EvoNetwwork.
        private Object _ID;
        //private List<Tuple<List<Dictionary<Int32, Int32>>, List<Int32>, List<Int32>>> _attributes;
        private List<List<int>> _attributes;

        private PriorGroup _priorGroup = null;
        private CurrentCluster _currentCluster = null;


        //public EvoObject(Object _ID, params List<int>[] _args)
        //{
        //    Debug.Assert(_args.Length >= 2, "Invalid attributes!");
        //    this._ID = _ID;
        //    _attributes = new List<List<int>>(_args.Length);

        //    for (int _i = 0; _i < _args.Length; _i++)
        //    {
        //        _attributes.Add(_args[_i]);
        //    }
        //}

        // Class constructor
        public EvoObject(Object _ID, List<int> _paper, List<int> _coauthor, List<int> _venue)
        {
            this._ID = _ID;
            _attributes = new List<List<int>>();

            _attributes.Add(_paper);
            _attributes.Add(_coauthor);
            _attributes.Add(_venue);
        }

        // Get original mapping object.
        public Object GetOriginalObject()
        {
            return _ID;
        }

        // Get attribute i of EvoObject
        public List<int> GetAttribute(int _index)
        {
            Debug.Assert(_index < _attributes.Count);
            return _attributes[_index];
        }

        // Set a prior group for EvoObject
        public void SetPriorGroup(PriorGroup _prior)
        {
            _priorGroup = _prior;
        }

        // Set current cluster for EvoObject
        public void SetCurrentCluster(CurrentCluster _current)
        {
            _currentCluster = _current;
        }

        // Get prior group for EvoObject
        public PriorGroup GetPriorGroup()
        {
            return _priorGroup;
        }

        // Get current cluster for EvoObject
        public CurrentCluster GetCurrentCluster()
        {
            return _currentCluster;
        }
    }
}
