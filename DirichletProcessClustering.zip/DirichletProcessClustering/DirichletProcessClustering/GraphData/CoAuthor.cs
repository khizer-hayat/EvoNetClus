﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.Interfaces;
using DirichletProcessClustering.GraphData;

namespace DirichletProcessClustering.GraphData
{
    // Class that is not included currently in the project
    public class CoAuthor : Interfaces.IAttribute
    {
        private List<INode> _targetObject;
        private List<IAttribute> _attributeList;
        public CoAuthor()
        {
            _attributeList = new List<IAttribute>();
        }
        //implementazion of _TargetObject INode method
        public List<INode> _TargetObject
        {
            get
            {
                return _targetObject;
            }
        }
        //implementazion of _AttributeObject INode method
        public List<IAttribute> _AttributeObject
        {
            get
            {
                return _attributeList;
            }
        }
        
        
        public int _coaID { get; set; }
        public string _coaName { get; set; }
        public List<Paper> _coaPapers { get; set; }

        public string _coaArea { get; set; }
    }
}
