﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirichletProcessClustering.GraphData
{
    // Class that is not included currently in the project
    public class Venue : Interfaces.IAttribute
    {
        public int _vID { get; set; }
        public string _vName { get; set; }
        public List<Paper> _vPapers { get; set; }

        public string _vArea { get; set; }

    }
}
