﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.GraphData;

namespace DirichletProcessClustering.GraphData
{
    // Class for separating attributes of Author as Papers....
    // i.e. to include all other attributes (coauthors, venues) in a single object i.e. Paper
    public class Paper
    {
        // Class constructor
        public Paper()
        { }

        public int _PaperID { get; set; }
        public List<int> _CoAuthors { get; set; }
        public int _VenueID { get; set; }
        public int _PaperCategory { get; set; }
        public int _Year { get; set; }
    }
}
