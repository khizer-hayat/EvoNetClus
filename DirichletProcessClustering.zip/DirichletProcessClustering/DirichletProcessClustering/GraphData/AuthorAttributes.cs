﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirichletProcessClustering.GraphData
{
    // Class for separating out the attributes of target object i.e. Author 
    // class is not currently in use in project
    public class AuthorAttributes
    {
        // Class constructor
        public AuthorAttributes()
        { }
        //public Dictionary<Int32, Int32> _Paper = new Dictionary<Int32, Int32>();
        //public int _CoAuthor_ID { get; set; }
        //public int _Venue_ID { get; set; }

        //public readonly Dictionary<Int32, Int32> _Paper = new Dictionary<Int32, Int32>();

        //public Int32 this[Int32 _key]
        //{
        //    // returns value if exists
        //    get { return _Paper[_key]; }

        //    // updates if exists, adds if doesn't exist
        //    set { _Paper[_key] = value; }
        //}
        public List<Paper> _Papers;
        public List<int> _PaperID;// = new List<int>();//  { get; set; }
        public List<int> _CoAuthorID;// { get; set; }
        public List<int> _VenueID;// { get; set; }
        public int _Year { get; set; }

        public List<int> GetPapers()
        {
            return _PaperID;
        }

        public List<int> GetCoAuthors()
        {
            return _CoAuthorID;
        }

        public List<int> GetVenues()
        {
            return _VenueID;
        }

        public int GetYear()
        {
            return _Year;
        }
    }
}
