﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DirichletProcessClustering.DataEngine;
using DirichletProcessClustering.Network;
using DirichletProcessClustering.GraphData;
//using DirichletProcessClustering.Interfaces;

namespace DirichletProcessClustering.GraphData
{
    // Class for Author (i.e. a Target Object convereted into EvoObject
    // ......interface implementation part commented
    
    // ......reason for trying interface approach was to implement it like a graph data structure in which 
    //.......authors are target vertices and papers, coauthors and venues are attribute vertices
    
    public class Author //: Interfaces.INode
    {
        // Class constructor
        public Author()
        { }
        //private List<INode> _targetList;
        //private List<IAttribute> _attributeObject;
        
        // Author class Constructor
       // public Author()
        //{
            //_targetList = new List<INode>();
        //}
        //implementazion of _TargetObject INode method
        /*public List<INode> _TargetObject
        {
            get
            {
                return _targetList;
            }
        }
        // implementazion of _AttributeObject INode method
        public List<IAttribute> _AttributeObject
        {
            get
            {
                return _attributeObject;
            }
        }*/

        public int _AuthorID { get; set; }
        public string _AuthorName { get; set; }
        //public AuthorAttributes _Attributes { get; set; }
        public List<Paper> _Papers { get; set; }

        public bool HasPapersForYear(int _year)
        {
            return _Papers.Any(_paper => _paper._Year == _year);
        }

        public bool HasPapersBetweenYears(int _startYear, int _endYear)
        {
            //_Papers.Where(_p => _p._Year >= _startYear && _p._Year <= _endYear);
            return _Papers.Any(_paper => _paper._Year >= _startYear && _paper._Year <= _endYear);
        }

        public List<Author> GetAuthorsByYear(List<Author> _fullList, int _year)
        {
            //return _fullList.Where(_author => _author._Papers.Any(_y => _y._Year == _year)).ToList();
            return _fullList.Where(_author => _author.HasPapersForYear(_year)).ToList();
        }

        public List<Author> GetAuthorsBetweenYears(List<Author> _fullList, int _startYear, int _endYear)
        {
            //return _fullList.Where(_author => _author._Papers.Any(_sY => _sY._Year >= _startYear && _eY._Year >= _startYear))).ToList();
            return _fullList.Where(_author => _author.HasPapersBetweenYears(_startYear, _endYear)).ToList();
        }

        // Get papers for author
        public List<int> GetPapers()
        {
            var _papers = new List<int>();
            foreach (var _paper in _Papers)
            {
                _papers.Add(_paper._PaperID);
            }
            return _papers;
        }

        // Get papers for a specific year for author
        public List<int> GetPapersByYear(int _year)
        {
            var _papers = new List<int>();
            foreach (var _paper in _Papers.Where(_p => _p._Year == _year))
            {
                _papers.Add(_paper._PaperID);
            }
            var _result = new HashSet<int>(_papers);
            return _result.ToList();
        }

        // Get papers with year and category between a specific years for author
        public Dictionary<int, Tuple<int, int>> GetPapersBetweenYears(int _startYear, int _endYear)
        {
            Dictionary<int, Tuple<int, int>> _papers = new Dictionary<int, Tuple<int, int>>();
            foreach (var _paper in _Papers.Where(_p => _p._Year >= _startYear && _p._Year <= _endYear))
            {
                _papers.Add(_paper._PaperID, new Tuple<int, int>(_paper._PaperCategory, _paper._Year));
            }
            //var _result = new HashSet<int>(_papers);
            //return _result.ToList();
            return _papers;
        }

        // Get coauthors for author
        public List<int> GetCoAuthors()
        {
            List<int> _coAuthors = new List<int>();
            foreach (var _paper in _Papers)
            {
                _coAuthors.AddRange(_paper._CoAuthors);
            }
            var _result = new HashSet<int>(_coAuthors);
            return _result.ToList();
        }

        // Get coauthors for specific year for author
        public List<int> GetCoAuthorsByYear(int _year)
        {
            var _coAuthors = new List<int>();
            foreach (var _paper in _Papers.Where(_p => _p._Year == _year))
            {
                _coAuthors.AddRange(_paper._CoAuthors);
            }
            var _result = new HashSet<int>(_coAuthors);
            return _result.ToList();
        }

        // Get coauthors between specific years for author
        public List<int> GetCoAuthorsBetweenYears(int _startYear, int _endYear)
        {
            var _coAuthors = new List<int>();
            foreach (var _paper in _Papers.Where(_p => _p._Year >= _startYear && _p._Year <= _endYear))
            {
                _coAuthors.AddRange(_paper._CoAuthors);
            }
            var _result = new HashSet<int>(_coAuthors);
            return _result.ToList();
        }

        // Get venues for author
        public List<int> GetVenues()
        {
            var _venues = new List<int>();
            foreach (var _paper in _Papers)
            {
                _venues.Add(_paper._VenueID);
            }
            var _result = new HashSet<int>(_venues);
            return _result.ToList();
        }

        // Get venues for specific year for author
        public List<int> GetVenuesByYear(int _year)
        {
            var _venues = new List<int>();
            foreach (var _paper in _Papers.Where(_paper => _paper._Year == _year))
            {
                _venues.Add(_paper._VenueID);
            }
            var _result = new HashSet<int>(_venues);
            return _result.ToList();
        }

        // Get venues between specific years for author
        public List<int> GetVenuesBetweenYears(int _startYear, int _endYear)
        {
            var _venues = new List<int>();
            foreach (var _paper in _Papers.Where(_p => _p._Year >= _startYear && _p._Year <= _endYear))
            {
                _venues.Add(_paper._VenueID);
            }
            var _result = new HashSet<int>(_venues);
            return _result.ToList();
        }       

        // Get author ID
        public int GetAuthorID()
        {
            return _AuthorID;
        }

        // Get author name
        public string GetAuthorName()
        {
            return _AuthorName;
        }
    }
}