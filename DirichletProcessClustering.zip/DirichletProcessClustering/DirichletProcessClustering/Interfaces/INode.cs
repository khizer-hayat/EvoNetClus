﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirichletProcessClustering.Interfaces
{
    // Interface for class Author
    public interface INode
    {
        List<INode> _TargetObject { get; }
        List<IAttribute> _AttributeObject { get; }
    }

    public interface IAttribute : INode
    {

    }
}
