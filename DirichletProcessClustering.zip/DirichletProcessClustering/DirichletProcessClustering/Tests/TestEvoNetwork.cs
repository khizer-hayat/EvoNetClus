﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using DirichletProcessClustering.GraphData;
using DirichletProcessClustering.Network;
using DirichletProcessClustering.DataEngine;
using DirichletProcessClustering.Clustering;
using DirichletProcessClustering.Utilities;

namespace DirichletProcessClustering.Tests
{
    // Class with Main() method used in project
    public class TestEvoNetwork
    {
        private static readonly int _ITERATIONS = 100;

        private static readonly int _START_YEAR = 2005;
        private static readonly int _END_YEAR = 2014;
        /** how many years should be included in a single time window. */
        private static readonly int _TIME_STEP = 2;
    
        private static readonly double _alpha = 0.05;  // controls the probability to generate a new cluster
        private static readonly double _gamma = 0.05;  // controls the probability to generate a new cluster
        private static readonly double[] _beta = new double[] { 0.01, 0.01, 0.09 }; // dirichlet prior distributions for each of attirbute type object
        private static readonly double _lambda = 0.5; // controls smoothness between clusters in adjacent time windows

        // the first three parameters should indicate the same number of attributes.
        private static readonly int _ATTR_COUNT = 3;
        
        // number of distinct values of papers, coauthors, venue
        // attribute size for 2005 - 2014
        //private static readonly int[] _ATTR_SIZE = new int[] {16068, 19411, 5720}; // Full List i.e. 499
        private static readonly int[] _ATTR_SIZE = new int[] { 463, 608, 306 }; // For TOP 10 Author_ID
        //private static readonly int[] _ATTR_SIZE = new int[] { 1781, 2424, 1098 }; // For TOP 50 Author_ID
        //private static readonly int[] _ATTR_SIZE = new int[] { 3641, 4715, 2005 }; // For TOP 100 Author_ID
        //private static readonly int[] _ATTR_SIZE = new int[] { 6847, 8639, 3259 }; // For TOP 200 Author_ID
        //private static readonly int[] _ATTR_SIZE = new int[] { 10204, 12685, 4215 }; // For TOP 300 Author_ID
        
        // Main Method
        public static void Main(String[] _args)
	    {
            Stopwatch _sw1 = new Stopwatch();
            _sw1.Start();
            // EvoNetwork main class
            EvoNetwork<Author> _mEvoNetwork = new EvoNetwork<Author>(_START_YEAR, _END_YEAR, _TIME_STEP, _ATTR_COUNT, _alpha, _beta, _lambda, _gamma, _ATTR_SIZE);
            // Create a collector which collects Author from DB. 
            EvoObjectCollector<Author> _mCollector = new AuthorCollector();//(_START_YEAR, _END_YEAR);
            
            // Create a converter which converts Author into EvoObject.
            EvoObjectConverter<Author> _mConverter = new AuthorPCVConverter();//_mCollector.GetCurrentCollection());
        
            // train
            Tuple<List<List<PriorGroup>>, List<List<CurrentCluster>>> _result = _mEvoNetwork.Build(_mCollector, _mConverter, _ITERATIONS);

            List<List<PriorGroup>>      _priorGroupsList        =   _result.Item1;          // item1 of tuple
            List<List<CurrentCluster>>  _currentClustersList    =   _result.Item2;          // item2 of tuple

            for (int _g = 0; _g < _priorGroupsList.Count; _g++)
            {
                List<PriorGroup> _priorGroups = _priorGroupsList[_g];
                List<CurrentCluster> _currentClusters = _currentClustersList[_g];
                DumpResults(_currentClusters, _priorGroups, (_START_YEAR + _g * _TIME_STEP));
            }
            _sw1.Stop();

            var _root = @"C:\Users\~\DirichletProcessClustering\Results";
            var _clusterFilename = "App_Stat.txt";
            TextWriter _twStat = File.CreateText(Path.Combine(_root, _clusterFilename));
            _twStat.WriteLine("Application execution Statistics");
            _twStat.WriteLine("---------------------------------");
            _twStat.WriteLine("\n");
            _twStat.WriteLine("Number of Target Objects :   {0}", _mCollector._collection.Count);
            _twStat.WriteLine("\n");
            _twStat.WriteLine("Number of Iterations     :   {0}", _ITERATIONS);
            _twStat.WriteLine("\n");
            _twStat.WriteLine("Number of Clusters       :   {0}", _currentClustersList[4].Count);
            _twStat.WriteLine("\n");
            _twStat.WriteLine("Time Elapsed             :   {0}", _sw1.Elapsed);
            _twStat.WriteLine("\n");
            _twStat.Flush(); _twStat.Close();
        }

    // @param year, year indicates the folder name to befa saved.
    private static void DumpResults(List<CurrentCluster> _curClusters, List<PriorGroup> _priorGroups, int _year) 
	{
        try 
        { 
            // make directory
            var _root = @"C:\Users\~\DirichletProcessClustering\Results";
            //var _directoryPath = _root + _year.ToString();
            var _clusterFilename = (_year + "-" + (int)(_year + 1)).ToString() + "_Cluster.txt";
            var _path = Path.Combine(_root, (_year + "-" + (int)(_year + 1)).ToString());
            if(!Directory.Exists(_path))
            {
                Directory.CreateDirectory(_path);
            }
            
            // output topk file
            TextWriter _twClus = File.CreateText(Path.Combine(_path, _clusterFilename));
            
            foreach (CurrentCluster _curCluster in _curClusters) 
            {
                // Print existing attribute information
                for (int _i = 0; _i < _ATTR_COUNT; _i++) 
                {
                    _twClus.WriteLine();
                    _twClus.WriteLine("Cluster_ID: {0} - Cluster_Size: {1} - Attribute_ID: {2} - Attribute_Size: {3}\n", _curCluster.GetClusterID(), _curCluster.GetClusterSize(), _i, _curCluster.GetNkA(_i));
                    _twClus.WriteLine("-----------------------------------------------------------------------------------");
                    UtilCS.KeyCountMap<Int32> _sorted = UtilCS.SortMapByDescendValue(_curCluster.GetAttributeKeyCountMap(_i));
                    
                    // only print top10
                    IEnumerator<Int32> _sortedIte = _sorted.KeySet().GetEnumerator();
                    //Iterator<Int32> _sortedIte = _sorted.keySet().iterator();
                    for (int _j = 0; _j < (_sorted.Size() > 10? 10 : _sorted.Size()); _j++) 
                    {
                        Int32 _key = _sortedIte.Current;
                        _twClus.WriteLine("{0} \t {1} \n", _key, _sorted.Get(_key));
                    }
                }

                _twClus.WriteLine("\n\n");
            } // traverse current clusters
            _twClus.Flush();
            _twClus.Close();
            
            // output obj_clus file

            var _objClusterFilename = ((_year + "-" + (int)(_year + 1)).ToString()) + "_ObjCluster.txt";
            _path = Path.Combine(_root, (_year + "-" + (int)(_year + 1)).ToString());
            if(!Directory.Exists(_path))
            {
                Directory.CreateDirectory(_path);
            }
            
            // output topk file
            TextWriter _twObjClus = File.CreateText(Path.Combine(_path, _objClusterFilename));
            //TextWriter _twObjClus = new PrintWriter(DUMP_FOLDER + _year + "//obj_clus.txt");
            foreach (CurrentCluster _curCluster in _curClusters)
			{
				_twObjClus.WriteLine("Cluster_ID: {0}, Cluster_Size: {1} \n", _curCluster.GetClusterID(), _curCluster.GetClusterSize());
				_twObjClus.WriteLine("--------------------------------------------------------------------------------");
				foreach (EvoObject _eEvoObject in _curCluster.GetClusterObjects())
				{
					Author _eAuthor = (Author)_eEvoObject.GetOriginalObject(); 
                    //Paper _ePaper = (Paper)_eEvoObject.GetOriginalObject();

                    _twObjClus.WriteLine(@"Author_ID: {0}, Author_Name: {1} ", _eAuthor._AuthorID, _eAuthor._AuthorName);

                    Dictionary<int, Tuple<int, int>> _tPapers = _eAuthor.GetPapersBetweenYears(_year, _year + 1);
                    foreach (var _kvpaper in _tPapers)
                    {
                        // Key is Paper_ID, Item1 is Paper_Category, Item2 is Year
                        _twObjClus.WriteLine("PaperID: {0}, PaperCategory: {1}, Year: {2}", _kvpaper.Key, _kvpaper.Value.Item1, _kvpaper.Value.Item2);
                    }
				} 
				_twObjClus.WriteLine("\n\n");
			}
			_twObjClus.Flush();
			_twObjClus.Close();

            var _pzFilename = (_year + "-" + (int)(_year + 1)).ToString() + "_PZ.txt";
            _path = Path.Combine(_root, (_year + "-" + (int)(_year + 1)).ToString());
                
            if(!Directory.Exists(_path))
            {
                Directory.CreateDirectory(_path);
            }
            
            // output topk file
            TextWriter _twPZ = File.CreateText(Path.Combine(_path, _pzFilename));
            
            // output PZ file
			_twPZ.WriteLine("Cluster_Count = " + _curClusters.Count + "\n");
			foreach (CurrentCluster _curCluster in _curClusters)
			{
				_twPZ.WriteLine("Cluster_ID: {0}, Cluster_Size: {1} \n", _curCluster.GetClusterID(), _curCluster.GetClusterSize());
				_twPZ.WriteLine("----------------------------------------------------------------");
				foreach (PriorGroup _prGrp in _priorGroups)
				{
					int _njk = _prGrp.GetNjk(_curCluster.GetClusterID());
					_twPZ.WriteLine("Prior_Group: {0}, Size: {1} \n", _prGrp.GetClusterID(), _njk);
				}
				_twPZ.WriteLine("\n\n");
			}
			_twPZ.Flush();
			_twPZ.Close();
        } 
        catch (FileNotFoundException _e) 
        {
            Console.WriteLine(_e.StackTrace);
        }
    }
        
    }
}
